package com.example.saucemonitor;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.content.Context;
import android.media.RingtoneManager;
import android.media.Ringtone;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    TextView tvStatus, tvDistance, tvR1, tvR2, tvR3;
    ProgressBar progressBar;
    Button btnStopAlarm;
    DatabaseReference dbRef;

    // Alarm components
    Vibrator vibrator;
    Ringtone currentRingtone;
    Handler handler = new Handler(Looper.getMainLooper());

    // State flags
    private volatile boolean isAlarming = false;
    private volatile boolean isSuppressed = false;      // user hit Stop
    private String currentStatus = "";                  // latest status from Firebase

    // Suppression runnable
    private final Runnable suppressionExpiryRunnable = new Runnable() {
        @Override
        public void run() {
            // suppression period ended — clear flag and re-evaluate
            isSuppressed = false;
            // If still need refill, start alarm again
            if ("Need Refill".equals(currentStatus)) {
                startAlarmImmediate();
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Bind Views
        tvStatus = findViewById(R.id.tvStatus);
        tvDistance = findViewById(R.id.tvDistance);
        tvR1 = findViewById(R.id.tvR1);
        tvR2 = findViewById(R.id.tvR2);
        tvR3 = findViewById(R.id.tvR3);
        progressBar = findViewById(R.id.progressBar);
        btnStopAlarm = findViewById(R.id.btnStopAlarm);

        // Init vibrator
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        // Hide stop button initially
        btnStopAlarm.setVisibility(View.INVISIBLE);

        // Stop Alarm button click
        btnStopAlarm.setOnClickListener(v -> {
            // User pressed stop: stop current alarm and suppress for 1 minute
            stopCurrentAlarm();
            scheduleSuppression(60 * 1000); // 1 minute
            btnStopAlarm.setVisibility(View.INVISIBLE);
        });

        // Firebase reference
        dbRef = FirebaseDatabase.getInstance().getReference("SensorData");

        // Listen for changes
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {
                if (!snapshot.exists()) return;

                String status = snapshot.child("Alert").getValue(String.class);
                Long avg = snapshot.child("Avg_cm").getValue(Long.class);
                Long r1 = snapshot.child("R1_cm").getValue(Long.class);
                Long r2 = snapshot.child("R2_cm").getValue(Long.class);
                Long r3 = snapshot.child("R3_cm").getValue(Long.class);

                // store currentStatus and update UI
                currentStatus = (status != null ? status : "");
                tvStatus.setText("Status: " + currentStatus);
                tvDistance.setText("Avg Distance: " + (avg!=null ? avg : "--") + " cm");
                tvR1.setText("R1: " + (r1!=null ? r1 : "--") + " cm");
                tvR2.setText("R2: " + (r2!=null ? r2 : "--") + " cm");
                tvR3.setText("R3: " + (r3!=null ? r3 : "--") + " cm");

                // update progress bar
                if (avg != null) {
                    progressBar.setProgress(avg.intValue());
                }

                // Decide alarm behaviour
                if ("Need Refill".equals(currentStatus)) {
                    // if currently suppressed (user hit Stop), do not ring now,
                    // but ensure a suppression expiry check is scheduled
                    if (isSuppressed) {
                        // suppressionExpiryRunnable already scheduled by stop; nothing to do
                    } else {
                        // not suppressed
                        // If not currently alarming, start immediate alarm
                        if (!isAlarming) {
                            startAlarmImmediate();
                        }
                        // else if already alarming, keep alarming until user stops or status changes
                    }
                    // change UI colors
                    progressBar.getProgressDrawable().setTint(Color.RED);
                    tvStatus.setTextColor(Color.RED);

                } else if ("Level Low".equals(currentStatus)) {
                    // stop any alarms and clear suppression
                    cancelSuppression();
                    stopCurrentAlarm();
                    btnStopAlarm.setVisibility(View.INVISIBLE);
                    progressBar.getProgressDrawable().setTint(Color.parseColor("#FFA500"));
                    tvStatus.setTextColor(Color.parseColor("#FFA500"));

                } else {
                    // OK or other status: cancel alarm & suppression
                    cancelSuppression();
                    stopCurrentAlarm();
                    btnStopAlarm.setVisibility(View.INVISIBLE);
                    progressBar.getProgressDrawable().setTint(Color.GREEN);
                    tvStatus.setTextColor(Color.GREEN);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                tvStatus.setText("Error: " + error.getMessage());
            }
        });
    }

    // Start an immediate alarm (one short ring + vibrate) and set alarming flag
    private void startAlarmImmediate() {
        if (isAlarming) return;
        isAlarming = true;

        // Show stop button so staff can mute temporarily
        btnStopAlarm.setVisibility(View.VISIBLE);

        // Vibrate briefly
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(500);
        }

        // Play ringtone (create fresh instance so it can play reliably)
        try {
            Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            currentRingtone = RingtoneManager.getRingtone(getApplicationContext(), notification);
            if (currentRingtone != null) {
                currentRingtone.play();
            }
        } catch (Exception e) {
            // ignore playback errors, but ensure we clear the alarming flag later
        }

        // Stop the ringtone automatically after 8 seconds (so it doesn't play forever)
        handler.postDelayed(() -> {
            stopCurrentAlarm(); // will set isAlarming=false
            // If still Need Refill and not suppressed, we want to keep alerting periodically.
            // We rely on the user to press Stop (which schedules a suppression check),
            // or the suppression expiry logic to re-trigger.
            if ("Need Refill".equals(currentStatus) && !isSuppressed) {
                // schedule next ring after 60s
                handler.postDelayed(() -> {
                    if ("Need Refill".equals(currentStatus) && !isSuppressed) {
                        startAlarmImmediate();
                    }
                }, 60 * 1000);
            }
        }, 8000);
    }

    // Stop the currently playing ringtone and clear alarming flag
    private void stopCurrentAlarm() {
        isAlarming = false;
        try {
            if (currentRingtone != null && currentRingtone.isPlaying()) {
                currentRingtone.stop();
            }
        } catch (Exception ignored) {}
        currentRingtone = null;
    }

    // When user presses Stop: suppress alarms for 'millis' ms and schedule check
    private void scheduleSuppression(long millis) {
        // set suppressed flag
        isSuppressed = true;
        // cancel any previous expiry runnable and re-schedule fresh one
        handler.removeCallbacks(suppressionExpiryRunnable);
        handler.postDelayed(suppressionExpiryRunnable, millis);
    }

    // Cancel suppression immediately (used when status changes to OK)
    private void cancelSuppression() {
        isSuppressed = false;
        handler.removeCallbacks(suppressionExpiryRunnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopCurrentAlarm();
        handler.removeCallbacksAndMessages(null);
    }
}
